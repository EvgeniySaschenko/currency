import Logo from '../_proto/Logo/Logo.jsx';

class LogoHeader extends Logo{
	constructor(props){
		super(props);
	}
}

export default LogoHeader;